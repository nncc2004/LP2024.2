public interface tieneAsentamientos{

    //Metodos abstractos
    //Sera comentado en las subclases que corresponda.
    public void visitarAsentamientos(Jugador jugador);
}