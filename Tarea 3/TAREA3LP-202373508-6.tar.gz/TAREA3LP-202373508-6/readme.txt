Estudiante: Nicolás Chehade Casivar
Rol: 202373508-6
Rut: 21652045-9
----------------------------------------
Instrucciones de compilacion y ejecucion:
Para la ejecución, se debe usar linux o wsl para windows. Desde la consola, usar el comando 'make' para compilar y luego 
'make run' para ejecutar el código.

Se está usando java 21.0.4 y javac 21.0.4

----------------------------------------
Instrucciones de juego:
Se inicia la partida orbitado el planeta en la posicion 0 del mapa galáctico. 
Tendrás 9 opciones mientras estés orbitando:
    Obtener información del planeta orbitado
    Visitar planeta
    Ver mapa Galáctico
    Viajar a otro planeta
    Descubrir nuevo planeta
    Recargar combustible
    Recargar energía traje
    Ver información nave, traje e inventario
    Terminar la partida 

Si visitas un planeta, tendrás 5 opciones diferentes:
    Volver a la órbita
    Obtener información del planeta actual
    Extraer recursos
    Buscar asentamientos
    Terminar la partida

Para ganar debes visitar el cento galactico con una eficiencia de la nave de por lo menos 50% (0.5)
Cada vez que te quedes sin energía del traje, volverás a la posición cero y perderas los rescursos extraidos. 
Sin embargo, las mejoras hechas se guardarán. 
Puedes quedarte sin energía hasta tres veces, luego de eso se acaba la partida. 