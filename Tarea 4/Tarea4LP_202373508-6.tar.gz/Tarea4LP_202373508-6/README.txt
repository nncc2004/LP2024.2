Nicolás Chehade Casivar
Rol: 202373508-6
Rut: 21.652.045-9

La entrega cuentas con P1.rkt, P2.rkt, P4.rkt que corresponden a las preguntas 1,2 y 4 respectivamente. 
Para ejecutarse desde dr. racket solamente debe abrirse el archivo con el programa y ejecutar ahí directamente. 
Se incluyen en cada archivo un par de casos de prueba, sean los proporcionados u otros. Se pueden modificar para 
probar en otros casos